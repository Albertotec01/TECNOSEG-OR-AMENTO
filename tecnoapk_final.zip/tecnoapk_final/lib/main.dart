import 'package:flutter/material.dart';

void main() {
  runApp(const TecnoSegApp());
}

class TecnoSegApp extends StatelessWidget {
  const TecnoSegApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TecnoSeg',
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(
          child: Text('Bem-vindo ao app TecnoSeg!', style: TextStyle(fontSize: 22)),
        ),
      ),
    );
  }
}
